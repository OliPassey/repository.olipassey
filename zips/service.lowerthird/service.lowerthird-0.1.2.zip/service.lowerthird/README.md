![LowerThird Logo](https://github.com/OliPassey/repository.olipassey/raw/master/service.lowerthird/logo.png)
#### by Oli Passey (Double T)
https://olipassey.me.uk

part of the Kodi Kontroller Project

JSON Trigger:

http://localhost:8080/jsonrpc?request={"jsonrpc":"2.0","method":"Addons.ExecuteAddon","params":{"addonid":"service.lowerthird","params":{"imageloc":"c:\\banners\\lt01.jpg","displaytime":"10000","position":"bottom"}},"id":1}
